# Governance: Idempotency & Webhooks (Authoritative)
Defines receipt-first webhook processing, event identity, and uniqueness constraints.

## Receipt-first pipeline (MUST)
This pipeline is written to:
- preserve the **"web is adapter only"** rule (no state transitions in web),
- while still enforcing **inbound security** (signature verification must happen where the raw body + headers exist).

1) Webhook controller **verifies the provider signature** (MUST).
   - Verification is **pure computation** (no outbound IO).
   - Use constant-time compare.
   - If invalid/missing: return 401/400 and **DO NOT enqueue** any job.

2) Controller computes `idempotency_key` and inserts `WebhookReceipt` (unique) (MUST).
   - Receipt insertion happens **only after verification** to prevent idempotency-key poisoning.
   - Store `verification_status = :verified`.

3) Controller enqueues one Oban job with `receipt_id` (MUST).

4) Worker loads receipt, asserts `verification_status == :verified`, normalizes `ProviderEvent`, and applies transitions **ONCE** (MUST).

### Optional defense-in-depth (MAY)
If you retain raw payload bytes for a limited window (per retention policy), the worker MAY re-verify the signature.
This is optional and MUST NOT be the only verification step.

## Canonical identities (MUST)

### WebhookReceipt.idempotency_key (MUST)
Purpose: dedupe raw inbound deliveries.

Canonical:
`idempotency_key = "#{provider}:#{delivery_id}"`

delivery_id MUST be:
- provider’s event id if present (preferred), else
- deterministic SHA-256 of (provider + normalized headers subset + raw body bytes)

Uniqueness:
- DB unique index on `webhook_receipts.idempotency_key`

### ProviderEvent.provider_event_key (MUST)
Purpose: dedupe normalized events (post verification).

Canonical:
`provider_event_key = "#{provider}:#{provider_event_id}"`

Uniqueness:
- DB unique index on `(provider, provider_event_id)` OR on `provider_event_key`

## Duplicate semantics (MUST)
- Duplicate WebhookReceipt insert: NOOP and return 200/204.
- Duplicate ProviderEvent insert: worker MUST NOOP (no transitions, no side effects).
- Optional: create an AuditLog entry noting duplicate receipt/event (scrubbed metadata only).

### Poisoning protection (MUST)
The system MUST NOT allow an unverified delivery to “claim” an idempotency key.
Therefore:
- Only verified deliveries may create `WebhookReceipt` rows.
- Invalid signature deliveries may be logged (rate-limited) but MUST NOT block later valid deliveries.

## Required fields (recommended)
WebhookReceipt:
- provider
- idempotency_key (unique)
- received_at
- raw_body (sensitive; retention-governed)
- headers_subset (sensitive; retention-governed)
- payload_sha256 (always keep)
- verification_status

ProviderEvent:
- provider
- provider_event_id
- provider_event_key
- event_type
- occurred_at
- receipt_id (fk)
- payload_sha256
- normalized_payload (scrubbed; optional)

## Coupling to retention (MUST)
- Raw payload retention is time-limited.
- payload_sha256 and minimal metadata persist beyond raw payload purge.
