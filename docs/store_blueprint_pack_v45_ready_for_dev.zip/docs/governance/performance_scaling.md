# Governance: Performance & Scaling (Authoritative)

Single-tenant does **not** mean “low traffic”. This blueprint must remain stable under spikes (launches, promos, checkout bursts) without turning into DB-thrash or LiveView re-render storms.

This doc is **law**. Phase docs may describe tactics, but these constraints define what is acceptable.

> Companion tactics doc: `docs/phases/phase_29_performance_architecture_optimizations.md`

---

## 1) Performance budgets (non‑negotiable)

These are target budgets for the **core commerce path**. If you cannot measure them, you cannot claim them.

### Public storefront
- **Shop list page**: p95 < 250ms server time (cached), p99 < 600ms
- **Product detail page**: p95 < 200ms (cached), p99 < 500ms
- **Search/filter** (when implemented): p95 < 350ms, p99 < 900ms

### Cart + checkout
- **Add to cart / update qty**: p95 < 150ms, p99 < 400ms
- **Cart render**: p95 < 250ms, p99 < 700ms
- **Checkout step transitions** (address/shipping/payment intent create): p95 < 400ms, p99 < 1200ms
- **End-to-end checkout** (human time excluded): p99 < 5s (includes payment intent create + redirect)

### Webhooks + background work
- **Webhook controller** (verify + enqueue only): p95 < 100ms, p99 < 250ms
- **Webhook apply worker** (idempotent transitions): p95 < 350ms, p99 < 1s
- **Email send worker**: bounded by provider; job must be replay-safe and non-blocking to order state

### Admin
- **Admin CRUD**: p95 < 500ms, p99 < 1500ms (excluding large exports)

---

## 2) Hot paths classification (MUST)

Every new surface must declare its hot-path tier:

- **Hot**: called frequently and/or during checkout (shop list, product, cart, shipping quote, checkout totals, webhook apply)
- **Warm**: admin screens, internal lists with pagination
- **Cold**: analytics, exports, backfills

**Rule:** Hot paths must be designed to work from caches first and avoid N+1 relationship loads.

---

## 3) Layered caching model

Use the following model consistently:

- **Hot**: ETS / in-memory cache (10s–5m TTL)
- **Warm**: Redis (30m–24h TTL)
- **Cold**: Postgres (durable source of truth)
- **Edge**: CDN for static assets
- **Client**: localStorage / IndexedDB for UX hints only (non-sensitive)

### Cache stampede protection (MUST for hot keys)
For hot cached reads (shop lists, product detail, shipping rules, price books):
- Use single-flight/coalescing (one recompute per key).
- Add jitter to TTLs to avoid synchronized expiries.
- If recompute fails, serve stale within a short grace window (where safe).

---

## 4) Redis key conventions (MUST)

Prefix keys by environment + app:

- `prod:store:<namespace>:...`
- `dev:store:<namespace>:...`

Avoid embedding PII in keys. Prefer IDs and deterministic hashes.

---

## 5) Recommended Redis structures (baseline)

Use Redis when you need fast reads under concurrency:

- **Rate limiting (auth/webhooks)**: `INCR` + `EXPIRE` or ZSET timestamps
- **Webhook dedupe**: STRING/SET with TTL (`webhook:<provider>:<event_id>`)
- **Catalog caches**: STRING JSON blobs (`catalog:list:<hash>`, `product:slug:<slug>`)
- **Shipping rules caches**: STRING JSON blobs per active ruleset
- **Inventory reservation helpers** (if used): HASH for holds + ZSET for expiry
- **Subscription renewal locks**: STRING with TTL to prevent double scheduling

---

## 6) TTL strategy (baseline)

- **Shop list**: 10s–60s (hot), warm 5m–30m
- **Product detail**: 30s–5m
- **Shipping rules**: 5m–60m (invalidate on admin update)
- **Price books**: 30s–10m (invalidate on update)
- **Webhook dedupe keys**: 24h–7d depending on provider replay window
- **Subscription renewal locks**: slightly longer than the renewal job window

### Invalidation triggers (baseline)
Invalidate caches on write actions, not on reads:

- Product publish/unpublish → invalidate catalog list + product detail caches
- Inventory adjustment / reservation release → invalidate product availability caches
- Shipping config change → invalidate shipping quote caches (or bump ruleset version)
- PriceEntry change → invalidate price book caches
- Coupon change → invalidate coupon caches (if/when implemented)

---

## 7) Database rules (Postgres) (MUST)

### 7.1 Indexes are part of the contract
If a hot path includes a query, the index must exist.

**Rule:** Every hot read surface doc must list:
- query pattern
- required index
- expected cardinality

### 7.2 Pagination discipline
- Public lists must be paginated, hard-capped (e.g., max 50–100 per page).
- Admin lists must be paginated and sortable only on indexed columns.
- Avoid unbounded `offset` paging on very large tables. If this becomes an issue, move to keyset-style pagination patterns.

### 7.3 Transaction scope discipline
- Keep transactions small and deterministic.
- Never perform outbound IO inside a DB transaction.
- For orchestrations requiring notifications: collect notifications inside the transaction and emit post-commit (already enforced elsewhere).

### 7.4 Avoid table scans in hot paths
Hot queries must avoid:
- `ILIKE '%term%'` without supporting strategy
- sorting on unindexed columns
- multi-join loads without constraints

---

## 8) Ash-specific performance rules (MUST)

### 8.1 Read surfaces are the optimization boundary
All hot reads must flow through **named read actions** or **domain read surfaces** that:
- constrain filters/sorts
- constrain `load` decisions
- enforce pagination caps
- keep authorization consistent

### 8.2 Relationship loading discipline
- Load only what you render.
- Prefer `select` + targeted loads instead of “load everything”.
- For admin grids, avoid loading large nested trees.

### 8.3 Aggregates/calculations
- Prefer cached aggregates for hot dashboards.
- For checkout totals, treat pricing/tax/shipping as deterministic functions with caching at the appropriate layer.

---

## 9) LiveView performance rules (MUST)

- Use streaming for list rendering (shop list, admin grids where appropriate).
- Debounce filter inputs; do not query on every keypress.
- Do not place large lists/maps directly into assigns without reason.
- Prefer server-side pagination and sorting; limit “in-memory sorting”.
- Avoid triggering a full rerender when only a small fragment changed.

---

## 10) Webhooks & external integrations (MUST)

- Webhook controller must **verify signature** and **enqueue only**.
- Controller must not mutate domain state.
- Workers apply state transitions with idempotency.
- Use dedupe keys for provider event IDs (warm cache or DB receipt uniqueness).

---

## 11) Oban queues & concurrency (MUST)

- Separate queues for:
  - webhooks
  - email delivery
  - digital grants
  - subscription renewals
  - backfills/maintenance

- Every worker that can be replayed MUST:
  - be idempotent
  - use uniqueness keys where appropriate
  - avoid heavy DB scans during peak

---

## 12) Observability (MUST)

Minimum telemetry/logging expectations:

- Request timing per surface (shop/product/cart/checkout/webhook)
- DB query count per request for hot paths (target: low and stable)
- Cache hit rate (catalog/product/shipping/price)
- Oban job timing + retry counts per queue
- Error code distribution (from `docs/governance/error_codes.md`)

**Rule:** any “log and continue” policy must emit a measurable signal.

---

## 13) Load testing scenarios (required before declaring “production ready”)

At minimum test:

- Shop list browse burst (cached hot)
- Product detail burst (cached hot)
- Cart update burst (write + read)
- Checkout burst (create intent + redirect flow)
- Webhook replay storm (duplicate deliveries)
- Subscription renewal window (many renewals at same hour)

---

## 14) Performance & Scaling Review (MANDATORY for new actions)

For every new hot-path action/surface, answer:

1) Data layer (hot/warm/cold)?
2) Safe under spike load (promo/checkout burst)?
3) DB indexes required (list them)?
4) Cache keys + TTL (list them)?
5) Invalidation triggers (list them)?
6) Stampede protection needed (yes/no, how)?
7) Does this introduce N+1 or large `load`s?
8) Can this be streamed/paginated instead of fully loaded?
9) Telemetry to add (events/metrics)?

If you cannot answer these, the work is not ready to merge in an enterprise blueprint.
