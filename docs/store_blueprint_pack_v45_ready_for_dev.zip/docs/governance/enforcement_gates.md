# Governance: Enforcement Gates (Authoritative)

This document defines **build-breaking gates**. If a rule is listed here as **(MUST)**, CI **must fail** when violated.

---

## mix check gates (MUST)

`mix check` MUST include, at minimum:

- format check
- compile warnings-as-errors
- tests
- credo (strict)
- docs generation
- blueprint gates (below)

Blueprint gate outputs SHOULD print `OK/FAIL` lines and fail fast.

---

## Blueprint gate index (MUST)

### Boundary gates (web is an adapter only)
1) **No Repo in web** (`check.no_repo_in_web`)
2) **No outbound HTTP in web** (`check.web_no_http`)
3) **No Oban enqueue in web** (`check.web_no_oban_enqueue`)
4) **No Ash.Query construction in web** (`check.web_no_ash_query`) *(add if not present yet)*
5) **No direct Ash.* calls in web** (`check.web_no_direct_ash_calls`) *(add if not present yet)*

### Hygiene gates
6) **No raw Req usage** (`check.req_usage`)
7) **@moduledoc required** (`check.moduledoc`)
8) **Docs-first phase notes present** (`check.docs_notes`)

### Governance test gates (state/ledger laws)
9) **Policy matrix drift** (tests under `test/store/governance/`)
10) **Error code registry completeness + uniqueness** (tests)
11) **Immutable snapshots (no update/destroy actions)** (tests)
12) **Pricing determinism + no penny leak** (tests)
13) **Inventory reservation (no oversell + idempotency)** (tests)
14) **Checkout interlocks (replay-safe exactly-once)** (tests)
15) **Refund semantics (role + step-up + caps + idempotency)** (tests)
O) **Cart conversion + merge idempotency** (tests)
18) **Shipping quote determinism + snapshot evidence** (tests)
19) **Email outbox idempotency (no duplicate receipts)** (tests)
20) **Digital grant issuance + revocation idempotency** (tests)
21) **Subscription renewal idempotency + boundary rules** (tests)

---

## 1) No Repo in web gate (MUST)

Fail if any file under `lib/store_web/**` references:

- `Store.Repo`
- any `Ecto.Repo` module

Preferred: Credo custom check (reports file+line)  
Fallback: mix task running ripgrep denylist

---

## 2) No outbound HTTP in web gate (MUST)

Fail if any file under `lib/store_web/**` references:

- `Req.`
- `Store.Support.HTTP.ReqClient`
- any HTTP client module used by the project

Allowlist:
- `lib/store_web/controllers/webhook_controller.ex` may **only enqueue** (no HTTP)

Rationale: web must not trigger side effects; side effects belong to workers/services.

See: `docs/governance/outbound_http.md`

---

## 3) No Oban enqueue in web gate (MUST)

Fail if any file under `lib/store_web/**` references:

- `Oban.insert`
- `Oban.insert_all`
- `Oban.insert!`
- `Oban.insert_all!`

Allowlist:
- `lib/store_web/controllers/webhook_controller.ex` may enqueue only

See: `docs/governance/side_effects_quarantine.md`

---

## 4) No Ash.Query construction in web gate (MUST)

**Definition of “off ad-hoc Ash.Query” (enforced):**

Under `lib/store_web/**`, web must not build queries using:

- `Ash.Query.*` (including `filter`, `sort`, `load`, `limit`, `offset`, `select`, `aggregate`, etc.)
- `Ash.read/2` or `Ash.read!/2` with an inline-built query
- resource-specific `read` calls that accept a query built in web

Web is allowed to:
- parse/normalize params into a **typed query contract struct** (domain-owned struct)
- call a **domain read surface** (facade) that applies the query contract using resource actions

Allowlist (strict and explicit):
- `lib/store_web/params/**` may reference the query contract structs, but must not call `Ash.Query.*`.

Implementation:
- Prefer a mix task denylisting `Ash.Query.` under `lib/store_web/**`
- Optionally allowlist known generated auth route modules if needed

---

## 5) No direct Ash.* calls in web gate (MUST)

Under `lib/store_web/**`, fail if code calls:

- `Ash.read/2`, `Ash.read!/2`
- `Ash.create/2`, `Ash.create!/2`
- `Ash.update/2`, `Ash.update!/2`
- `Ash.destroy/2`, `Ash.destroy!/2`

Allowed patterns:
- **AshPhoenix.Form** is used in LiveViews/components (forms own the Ash calls)
- A controller/liveview calls **domain facade functions** (e.g. `Store.Orders.*`, `Store.Payments.*`)
- `AshJsonApi.Router` handles API requests (JSON API layer owns Ash calls)

Allowlist:
- `lib/store_web/auth/**` and/or generated auth route modules (only if required by AshAuthentication)

---

## 6) @moduledoc gate (MUST)

Fail if any module under `lib/**` lacks `@moduledoc`  
(allow explicit `@moduledoc false`).

---

## 7) Docs-first notes gate (MUST)

Required (minimum for release-1):

- `docs/agent_notes/phase_00_docs.md`
- `docs/agent_notes/phase_01_docs.md`
- `docs/agent_notes/phase_02_docs.md`
- `docs/agent_notes/phase_03_docs.md`

The phase list should expand as phases expand.

---

## 8) No raw Req usage gate (MUST)

CI must fail if `Req.` is referenced outside the HTTP wrapper module.

- Scope: `lib/store/**`
- Allowlist: wrapper file only

---

## 9) Policy matrix test gate (MUST)

- The pinned policy matrix must have an accompanying test suite under `test/store/governance/`.
- CI must fail if authorization drift occurs.

See: `docs/governance/policy_matrix.md`

---

## 10) Error code registry gate (MUST)

- The error code registry must contain all pinned codes from `docs/governance/error_codes.md`.
- Tests must assert core codes exist and remain unique.

---

## 11) Immutable snapshot gates (MUST)

- Snapshot resources must not define update/destroy actions.
- Add a test gate asserting action absence.

See: `docs/governance/immutable_snapshots.md`

---

## 12) Pricing determinism gates (MUST)

- Pricing evaluation must be deterministic for identical inputs.
- Discount allocation must have no penny leak and deterministic remainder distribution.
- Applied discount ordering must be deterministic.

See: `docs/governance/pricing_determinism.md`

---

## 13) Inventory reservation gates (MUST)

- Order creation must enforce no-oversell for inventory-tracked SKUs.
- Reservation creation must be concurrency-safe and idempotent.
- Expired reservations must be released by a scheduled worker.

See: `docs/governance/inventory_reservations.md`

---

## 14) Checkout interlock gates (MUST)

- `begin_checkout` must be idempotent (checkout_key uniqueness).
- payment_intent creation must be idempotent (payment_intent_key uniqueness).
- Paid side effects must be exactly-once under webhook and redirect replays.

See: `docs/governance/checkout_interlocks.md`

---

## 15) Refund semantics gates (MUST)

- Refund actions require role + step-up.
- Refunds must be idempotent (unique idempotency_key).
- Refund amount must not exceed refundable amount.
- Order status transitions to refunded only when refund evidence confirms.

See: `docs/governance/refund_semantics.md`

---

## 16) Post-commit notifications gate (MUST)

Goal: prevent “committed state but missed notifications”.

Requirements:
- Test env MUST set: `config :ash, :missed_notifications, :raise`
- Any transactional Ash writes that rely on notifications MUST use:
  - `return_notifications?: true` inside the transaction
  - `Ash.Notifier.notify/1` after commit (post-commit notify wrapper)
- A governance test MUST cover replay-safe flows to ensure no regressions.

Recommended test:
- `test/store/governance/post_commit_notifications_test.exs`

Note:
- Post-commit notifier failures MUST NOT trigger retry loops for already-committed state.
  Use “log and continue” (default) or a dedicated idempotent notify job if you require delivery guarantees.
---

## 17) Cart conversion + merge idempotency gate (MUST once carts exist)

Goal: prevent duplicate orders, duplicate reservations, or “lost carts” when:
- the user double-clicks checkout,
- the browser refreshes,
- the user logs in mid-checkout (guest → user merge),
- the checkout handoff is retried by a worker.

Requirements:
- Cart → Order conversion MUST be idempotent (stable key, e.g. `cart_id` + `conversion_nonce`).
- A Cart MUST be “converted” at most once (DB uniqueness preferred).
- Guest cart merge into user cart MUST be deterministic (conflict rules defined).
- A governance test MUST assert:
  - converting the same cart twice yields one order
  - merge + convert does not create duplicates

Recommended tests:
- `test/store/governance/cart_conversion_idempotency_test.exs`
- `test/store/governance/cart_merge_determinism_test.exs`

---

## 18) Shipping quote determinism + snapshot evidence gate (MUST once shipping exists)

Goal: ensure totals are reproducible and auditable.

Requirements:
- Shipping quote computation MUST be deterministic for a given input snapshot.
- Checkout MUST persist the selected shipping adjustment with:
  - a quote hash (inputs → hash)
  - an address snapshot (or address hash)
  - the selected method identifier
- Rule changes MUST NOT alter historical paid orders.

A governance test MUST assert:
- same quote input → same output (within rounding rules)
- paid order retains original shipping adjustment after rule changes

Recommended test:
- `test/store/governance/shipping_quote_determinism_test.exs`

---

## 19) Email outbox idempotency gate (MUST once email delivery exists)

Goal: prevent duplicate receipts/notifications under:
- webhook replay,
- Oban retries,
- user refreshes.

Requirements:
- All emails MUST be written to a durable outbox resource (or equivalent) before sending.
- Sends MUST be idempotent with a unique key (e.g. `order_id` + `template_key` + `recipient`).
- The delivery worker MUST be safe to retry.

A governance test MUST assert:
- same trigger twice creates one outbox row
- worker retry does not send duplicates

Recommended test:
- `test/store/governance/email_outbox_idempotency_test.exs`

---

## 20) Digital grant issuance + revocation idempotency gate (MUST once digital exists)

Goal: prevent duplicate grants, and enforce refund-linked revocation.

Requirements:
- Grant issuance MUST be idempotent per (order_line_item_id, asset_id).
- Grant access MUST be gated by the grant state (active/revoked/expired).
- Refund policy MUST define if/when grants are revoked, and revocation MUST be idempotent.

A governance test MUST assert:
- duplicate “paid” replay → one grant
- refund replay → one revocation effect
- revoked/expired grant cannot generate a signed URL

Recommended test:
- `test/store/governance/digital_grants_idempotency_test.exs`

---

## 21) Subscription renewal idempotency + boundary rules gate (MUST once subscriptions exist)

Goal: prevent double charges and enforce lifecycle boundaries.

Requirements:
- Renewal attempts MUST be idempotent per (subscription_id, period_key).
- Renewals MUST be scheduled by workers (Oban), not web.
- Subscription activation MUST occur only after first payment success (replay-safe).
- Plan/variant changes MUST obey boundary rules (MVP: at period boundaries only unless proration is explicitly implemented).

A governance test MUST assert:
- duplicate renewal job → one renewal order + one payment intent
- cancellation race does not renew after cancel_now
- cancel_at_period_end renews until boundary then stops

Recommended test:
- `test/store/governance/subscription_renewal_idempotency_test.exs`

