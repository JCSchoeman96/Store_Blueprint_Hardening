# Store Blueprint — Implementation Roadmap (Single-Tenant)

**Status:** Blueprint execution order + milestone gates  
**Last updated:** 2026-02-27

This roadmap is the single “how to build” reference when cloning this blueprint for a client. It sequences work to reach a **fully functioning ecommerce store** (simple physical products first) while preserving the blueprint’s non-negotiable laws:

- Web is an adapter only (no ad-hoc querying or authorization-meaningful logic in `store_web/**`).
- Domain facades + resource actions are the entrypoints.
- Determinism and idempotency are enforced by governance tests and gates.
- Side effects are quarantined (webhooks verify + enqueue; workers apply state).
- Performance laws apply to hot paths (Phase 29).

---

## What “Fully Functioning Ecommerce” Means (Definition of Done)

A store is considered **fully functioning** (for simple physical products) when:

1) **Catalog**
- Admin can create/update/publish products and categories
- Stock tracked (inventory)
- Public storefront can list and view products

2) **Cart + Checkout**
- Guest/user can add/remove/update cart items
- Checkout captures shipping address and selects a shipping option
- Deterministic totals are shown (items + tax + shipping)

3) **Payment**
- Payment intent created and customer completes payment with a real provider
- Webhook verification is enforced and replay-safe
- Paid state is applied exactly once

4) **Fulfillment**
- Order moves into fulfillment workflow after paid
- Admin can mark packed/shipped, optionally with tracking

5) **Customer Notifications**
- Customer receives receipt/confirmation email (idempotent)
- Customer can view order status in account

6) **Operational Baselines**
- `mix check` passes
- Governance gates pass
- Performance review completed for hot paths
- Basic observability exists (logging, key telemetry events)

---

## Milestones (Client-Ready Execution Order)

### Milestone 0 — Baseline Integrity (Already achieved in this blueprint)
**Goal:** foundation laws + governance gates

**Includes:**
- Phase 00–14 foundation
- Post-commit notifications discipline (test-time raise)
- Enforcement gates (`mix check`)

**Exit criteria:**
- `mix check` green
- Governance suite green
- No missed-notification warnings in test (must fail fast)

---

### Milestone 1 — Interface Spine Refactor (P0, do before expanding features)
**Goal:** prevent web query drift before storefront explosion

**Docs:**
- Phase 15: `docs/phases/phase_15_ash_interfaces_web_query_discipline.md`
- Phase 18: `docs/phases/phase_18_ash_code_interfaces_and_write_surfaces.md`

**Exit criteria (hard):**
- `store_web/**` contains no ad-hoc `Ash.Query.*`
- Controllers/LiveViews call only domain facades / AshPhoenix.Forms
- Known offenders fixed (e.g., `order_api_controller.ex`, `admin_live.ex`)

---

### Milestone 2 — Admin CRUD foundations via AshPhoenix.Form
**Goal:** learn and standardize form patterns in low-risk admin surfaces

**Docs:**
- Phase 16: `docs/phases/phase_16_ash_phoenix_forms_admin_crud.md`

**Exit criteria:**
- Shipping/Tax/Pricing admin CRUD uses AshPhoenix.Form
- No direct `Ash.create/update/destroy` in admin LiveViews

---

### Milestone 3 — Catalog (Simple Products Only)
**Goal:** sellable catalog for physical items

**Docs:**
- Phase 19: `docs/phases/phase_19_catalog_simple_products.md`

**Exit criteria:**
- Product lifecycle states (draft/published/archived) working
- Public `/shop` and `/shop/:slug` pages work
- Inventory prevents oversell at the domain layer

---

### Milestone 4 — Storefront + Cart UX
**Goal:** customer can add to cart and proceed to checkout start

**Docs:**
- Phase 20: `docs/phases/phase_20_storefront_cart_ux.md`

**Exit criteria:**
- Guest cart (`cart_token`) works
- Cart merge on login works
- Cart conversion to checkout/order start is idempotent
- Hot-path performance review completed (Phase 29)

---

### Milestone 5 — Checkout + Payment Integration (Real money path)
**Goal:** the store can accept payments safely

**Docs:**
- Phase 21: `docs/phases/phase_21_checkout_payment_integration_mvp.md`
- Governance: side effects quarantine + idempotency docs

**Exit criteria (hard):**
- Provider integration exists (sandbox)
- Webhook controller verifies signature + enqueues
- Worker applies payment success once (replay safe)
- Customer sees success page (read-only)
- Orders marked paid exactly once

---

### Milestone 6 — Shipping + Fulfillment
**Goal:** physical goods pipeline post-payment

**Docs:**
- Phase 22: `docs/phases/phase_22_shipping_fulfillment_physical_products.md`

**Exit criteria:**
- Shipping quote determinism + snapshot evidence
- Fulfillment workflow exists (pending → shipped)
- Admin can progress fulfillment
- Customer can view fulfillment status (direct or via order read model)

---

### Milestone 7 — Email/Receipts/Notifications Spine
**Goal:** “customer gets notified” is real and idempotent

**Docs:**
- Phase 23: `docs/phases/phase_23_email_receipts_notifications_spine.md`

**Exit criteria (hard):**
- EmailOutbox + delivery worker implemented
- Receipt email is idempotent (no duplicates on webhook retries)
- Operational logs/telemetry for delivery outcomes

---

### Milestone 8 — Optional expansions (choose per client)
These are deliberate add-ons and should not contaminate Orders core logic.

#### 8A — Digital products
**Docs:**
- Phase 24: `docs/phases/phase_24_digital_products_download_grants.md`

**Exit criteria:**
- Grants issued post-payment (idempotent)
- Signed URLs short-lived and grant-gated
- Refund-linked revocation policy enforced

#### 8B — Variable products (variants)
**Docs:**
- Phase 25: `docs/phases/phase_25_variable_products_variants.md`

**Exit criteria:**
- Variants are sellable units
- Per-variant pricing/inventory overrides work
- No branching inside Orders for product type

#### 8C — Subscriptions (simple → variable)
**Docs:**
- Phase 26: `docs/phases/phase_26_simple_subscriptions.md`
- Phase 27: `docs/phases/phase_27_variable_subscriptions.md`

**Exit criteria (hard):**
- Renewals are Oban-only
- Renewal idempotency per period via `renewal_key`
- Cancellation boundaries enforced

---

### Milestone 9 — Production Readiness
**Goal:** go-live readiness

**Docs:**
- Phase 28: `docs/phases/phase_28_production_readiness_release_checklist.md`

**Exit criteria:**
- Secrets/config correct in `runtime.exs`
- Backups and restore drill documented
- Observability baseline exists
- Smoke tests pass end-to-end

---

## Hard “No” List (Blueprint invariants)
- No direct DB access in web (`Repo`/Ecto) — gate enforced.
- No outbound HTTP in web (except signature verification is not outbound IO).
- No “apply paid/refund” in controller/LiveView — worker only.
- No ad-hoc `Ash.Query` in web — gate enforced.
- No product-type branching in Orders core logic; fulfillment/grants/subscriptions live outside.

---

## Required Commands (every milestone)
- `mix check`
- Run the governance suite relevant to the milestone you touched
- Update a phase note under `docs/agent_notes/` (links + approach + perf review)

---

## Where performance fits (Phase 29)
Performance is not “later.” It is applied:
- **before** hot-path designs (to lock the laws),
- **during** implementation (per-surface review),
- **after** (load testing + go-live verification).

Reference:
- `docs/phases/phase_29_performance_architecture_optimizations.md`
- `docs/governance/performance_scaling.md`
