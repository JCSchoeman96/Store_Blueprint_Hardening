# AGENTS.md (MANDATORY)

This repository is an **enterprise-grade, single-tenant** Ash 3.x + Phoenix LiveView ecommerce blueprint.

Your job is to implement phases **without breaking governance**. Correctness and enforceable invariants beat speed.

---

## Non-Negotiable Rules (Fail the build if violated)

### Web boundary discipline
- **DO NOT** construct queries in web.
  - No `Ash.Query.*` in `lib/store_web/**` (filter/sort/load/limit/offset/aggregate).
  - No direct `Ash.read/create/update/destroy` in `lib/store_web/**`.
- Web is an adapter only:
  - Parse params → normalize → call **domain facade** functions.
  - Rendering + UI state only.

### Inbound webhooks (security boundary)
- Webhook controllers **MUST** verify webhook signatures inline.
  - Signature verification is **allowed** in web because it is inbound security (pure computation).
  - Verification must use the **raw request body** + headers.
- Webhook controllers **MUST NOT** mutate domain state.
  - No order/payment transitions in controllers.
  - No outbound HTTP calls.
- Allowed controller work:
  - Verify signature
  - Normalize into a canonical receipt struct
  - (Optional, recommended) Persist a `WebhookReceipt`
  - Enqueue **exactly one** Oban job
- Workers perform state transitions through domain facades only.

### Payment return/cancel routes are read-only
- Return/cancel routes **MUST NOT** apply payment state.
  - Do not mark paid, do not create refunds, do not "confirm" anything.
  - Never trust query-string parameters as proof of payment.
- The UI can display current state and instruct the user to refresh.

### Provider adapter boundaries
- Provider modules must be **pure** boundaries:
  - create intent payload/redirect URL parameters
  - verify signature
  - normalize provider payload → canonical receipt
- Provider modules **MUST NOT**:
  - write to DB (`Repo.*`)
  - call `Ash.*`
  - enqueue Oban jobs
  - embed business rules
- Domain + workers own orchestration and invariants.

### Email sending boundary
- No email sending in web.
- Email sending must be:
  - behind a single wrapper module (example: `Store.Comms` / `Store.Notifications`)
  - executed via Oban jobs
  - idempotent (keyed by `order_id` + `template_kind` or equivalent)
- If adding email delivery, add a unique constraint to prevent duplicates.

### Domain surfaces are the only entrypoints
- Every controller/LiveView/worker must go through one of:
  - `Store.Orders.*`
  - `Store.Payments.*`
  - `Store.Pricing.*`
  - `Store.Catalog.*`
  - `Store.Carts.*`
  - `Store.Checkout.*`
  - `Store.Shipping.*`
  - `Store.Fulfillment.*`
  - `Store.Comms.*`
  - `Store.Digital.*`
  - `Store.Subscriptions.*`
- Domain functions must:
  - accept an `actor` (or explicit system actor in workers)
  - accept a typed **query/input struct** (NOT arbitrary params)
  - call resource actions / code interfaces (Ash is the truth)

### Subscription non-negotiables
- Renewals are **Oban-only**. Never trigger renewals from web.
- Renewal idempotency uses a unique `renewal_key` per subscription per billing period.
- Subscription activation happens **after first payment succeeds** (interlock/worker), not on return URLs.

### Digital delivery non-negotiables
- All digital access is **grant-gated** (`DownloadGrant`). No direct asset URLs.
- Signed download URLs must be **short-lived** and generated on demand.
- Download counters (if used) must use optimistic locking / replay-safe updates.
- Refund-linked revocation must be idempotent and run in workers.

### Email outbox non-negotiables
- Emails must be sent via an outbox + Oban worker (no direct sends).
- Enforce a unique constraint to prevent duplicate sends (e.g. `order_id` + `template_kind`).


### Query Contracts
- Query structs live in the **domain** (reused by web + API + jobs).
  - Example location: `lib/store/orders/queries/order_index_query.ex`
- Web param parsing modules may exist, but must only:
  - coerce + validate params
  - build the domain query struct
  - never build `Ash.Query` directly

### Notifications & transactions (post-commit rule)
- If an Ash write happens inside a DB transaction and notifications matter:
  - use `return_notifications?: true` on the Ash call
  - collect notifications inside the transaction
  - call `Ash.Notifier.notify/1` **after commit** (use the shared wrapper)
- In tests, `config :ash, :missed_notifications, :raise` must remain enabled.

### One public API layer (no duplication)
- If adding a public API, use **`ash_json_api` only** for v1.
- Do not add `ash_graphql` until a conscious phase decision exists.

---

## Preferred Ash Patterns (Use the framework fully)

### Use resource actions, not ad-hoc logic
- Put rules in:
  - `validations`
  - `changes`
  - `policies`
  - `calculations`
  - `aggregates`
- Prefer `code_interface` functions for stable call sites.

### LiveView admin CRUD
- Use `AshPhoenix.Form` for create/update.
- Use `AshPhoenix.FilterForm` for safe filtering.
- LiveViews should not contain business rules; they should orchestrate forms.

### Read surfaces
- Provide one canonical read surface per consumer type:
  - `*_for_public`
  - `*_for_user`
  - `*_for_admin`
- Each surface owns:
  - scoping
  - allowed filters/sorts
  - default loads

---


## Performance enforcement (Phase 29) — mandatory on hot paths

If your change touches any **hot-path surface**, you MUST include a **Performance & Scaling Review** in the PR/bead notes and follow the rules below.

### Hot-path surfaces (always treated as performance-critical)
- Storefront product listing / product detail reads
- Cart reads/mutations (add/remove/update/merge/convert)
- Checkout (pricing/tax/shipping quote, payment intent creation)
- Payment webhooks (verify + enqueue) and webhook workers (apply transitions)
- Email delivery (outbox insert + delivery worker)
- Digital downloads (grant checks + signed URL issuance)
- Subscription renewals (scheduler + renewal worker)

### Required PR/bead “Performance & Scaling Review” checklist
Reference: `docs/governance/performance_scaling.md` and `docs/phases/phase_29_performance_architecture_optimizations.md`

- Data layer: does this belong to **hot / warm / cold**?
- DB calls: did you introduce any new queries? Any N+1 risk?
- Indexes: are all new query paths indexed? (add migrations if needed)
- Caching: what is cached (ETS/Cachex vs Redis)? TTL? Invalidation triggers?
- Stampede: how do you prevent thundering herd / cache stampedes?
- LiveView: are lists paginated/streamed? any large assigns?
- Oban: is heavy work off the request path? uniqueness/idempotency keys set?
- Observability: telemetry/logging added for new hot-path operations?

### Enforcement expectations
- Hot-path changes that do not include the checklist above are **rejected**.
- Never “fix performance later” by adding cache after the fact; follow the laws first.
- Always run:
  - `mix check`
  - relevant governance tests (at minimum the suite touching your surface)

## Operational Discipline

### Before implementing any task
1) Read the relevant phase doc under `docs/phases/`.
2) Web-search the current upstream docs (Hexdocs) for:
   - Ash 3.x
   - AshPhoenix
   - AshJsonApi
   - Oban, Req, Bandit (if touched)
3) Write/update the phase note under `docs/agent_notes/`:
   - links consulted
   - recommended approach
   - intended implementation
   - performance/scaling review (hot/warm/cold, indexes, caches)

### After implementing any task
- Run:
  - `mix check`
- If you used Igniter:
  - `git diff --stat`
  - `mix check`
  - record exactly what changed in the phase note

---

## Performance & Scaling Review (Required mindset)
Even for a single-tenant store:
- Avoid N+1 loads; constrain loads in read surfaces.
- Index critical query paths (foreign keys, status fields, timestamps, unique keys).
- Keep write paths idempotent and replay-safe.
- Prefer async jobs (Oban) for heavy work, but do not leak Oban inserts into web.

---

## If you are unsure
- Do not invent patterns.
- Find the best-practice in Hexdocs, cite it in the phase note, then implement the smallest correct change.
